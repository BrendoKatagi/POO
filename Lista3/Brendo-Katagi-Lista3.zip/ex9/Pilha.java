package ex9;

import java.util.LinkedList;

public class Pilha {
    private LinkedList<Object> lista;

    public void inicializa(){
        lista = new LinkedList<Object>();
    }

    public void pop(){
        if(!(lista.isEmpty())){
            System.out.println("Desempilhando ...");
            System.out.println(this.top() + " Retirado");
            lista.removeFirst();
        }
    }

    public void push(Object x){
        lista.addFirst(x);
    }
    
    public Object top(){
        if(!(lista.isEmpty())){
            return lista.getFirst();
        }

        System.out.println("lista está vazia!");
        return null;

    }

    public static void main(String[] args) {
        Pilha p1 = new Pilha();
        p1.inicializa();

        p1.push("item1");
        p1.push("item2");
        p1.push(3);

        System.out.println("Topo: " + p1.top());

        p1.pop();
        System.out.println("Topo: " + p1.top());
    }
}
