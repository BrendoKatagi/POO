
public class ex8 {

    public static class NoDeArvore {
        int item; // Um it e m na á r v o r e .
        NoDeArvore esquerda; // P o nt . sub−á r v o r e e s q u e r d a .
        NoDeArvore direita; // P o nt . sub−á r v o r e d i r e i t a .

    }

    public static class arvoreBinaria{
        NoDeArvore raiz;

        public void inicializa(){
            raiz = null;
        }

        public NoDeArvore insere(NoDeArvore noAtual, int valor){

            if(noAtual == null){
                noAtual= new NoDeArvore();

                noAtual.item = valor;
                noAtual.direita = null;
                noAtual.esquerda = null;

                if(raiz == null){
                    raiz = noAtual;
                }
            
            }else{

                if(valor >= noAtual.item){ //se o valor foi maior ou igual insere na sub arvore da direita
                    noAtual.direita = insere(noAtual.direita, valor);
                
                }else{//se o valor foi menor insere na sub arvore da esquerda
                    noAtual.esquerda = insere(noAtual.esquerda,valor);
                }
            }

            return noAtual;
        }

        public void imprimeArvore(NoDeArvore noAtual ){
            if(noAtual != null){
                System.out.println(noAtual.item);
    
                imprimeArvore(noAtual.direita);
                imprimeArvore(noAtual.esquerda);
            } 
        }

        public NoDeArvore buscaNo(NoDeArvore noAtual, int valor){
            NoDeArvore aux = null;

            if(noAtual != null){

                if(valor > noAtual.item){ //se o valor é maior busca na sub árvore da direita

                    aux = buscaNo(noAtual.direita, valor);
                
                }else if(valor < noAtual.item){//se o valor é maior busca na sub árvore da esquerda

                    aux = buscaNo(noAtual.esquerda, valor);
                
                }else{ //valor é igual

                    System.out.println("Valor encontrado!");
                    aux = noAtual;
                }
            }

            if(aux == null){
                System.out.println("Valor não encontrado!");   
            }
            return aux;
        }

        public NoDeArvore maiorNo(NoDeArvore noAtual){
            NoDeArvore aux;

            if(noAtual.direita == null){
                aux = noAtual;
            
            }else{
                aux = maiorNo(noAtual.direita);
            }

            return aux;
        }

        public NoDeArvore removeNo( int valor){

            NoDeArvore aux  = raiz;
            NoDeArvore destino;
            NoDeArvore pai = null;

            while (aux != null && aux.item != valor){
                pai = aux; // pai recebe o auxiliar

                if (valor > aux.item) {
                    aux = aux.direita;
                }
                else {
                    aux = aux.esquerda;
                }
            }

            if(aux != null){

                if(aux.esquerda == null && aux.direita == null){ //sem filhos
                    if(aux == raiz){
                        aux = null;
                        raiz = aux;
                    }else{
                        if(pai.direita == aux){
                            pai.direita = null;
                        }else{
                            pai.esquerda  = null;
                        }
                    }

                }else{
                    if(aux.esquerda == null){ //somente o filho da esquerda é null
                        if(aux != raiz){
                            if(pai.direita == aux){
                                pai.direita = aux.direita;
                            }else{
                                pai.esquerda = aux.direita;
                            }
                        }else{
                            raiz = aux.direita;
                        }
                        
                    
                    }else if(aux.direita == null){//somente o filho da direita é null
                        if(aux != raiz){
                            if(pai.direita == aux){
                                pai.direita = aux.esquerda;
                            }else{
                                pai.esquerda = aux.esquerda;
                            }
                        }else{
                            raiz = aux.esquerda;
                        }
                    
                    }else{ //dois filhos
                        destino = maiorNo(aux.esquerda);
                        int valorAux = destino.item;
                        raiz = removeNo(destino.item);
                        aux.item = valorAux;
                    }
                }

            }
            return raiz;
        }

        public int soma(NoDeArvore noAtual){

            int soma = noAtual.item;

            if(noAtual.direita != null){
                
                soma += soma(noAtual.direita);
            }
            if(noAtual.esquerda != null){

                soma += soma(noAtual.esquerda);
            }

            return soma;

        }

    }

    public static void main(String[] args) {
        
        arvoreBinaria tree = new arvoreBinaria();
        tree.inicializa();

        tree.insere(tree.raiz, 10);
        tree.insere(tree.raiz, 5);
        tree.insere(tree.raiz, 20);
        tree.insere(tree.raiz, 2);
        tree.insere(tree.raiz, 30);
        tree.insere(tree.raiz, 15);
        
        ///ARVORE INSERIDA:
        //////10
        ////5////20
        //2////15///30

        System.out.println("Arvore Binaria:");
        tree.imprimeArvore(tree.raiz);
        System.out.println();
        //tree.buscaNo(tree.raiz, 20);
        tree.raiz = tree.removeNo(20);
        System.out.println("Arvore Binaria:");
        tree.imprimeArvore(tree.raiz);
        System.out.println();

        int valorSoma = tree.soma(tree.raiz);
        System.out.println("Valor da soma: " + valorSoma);

    }
    
}
