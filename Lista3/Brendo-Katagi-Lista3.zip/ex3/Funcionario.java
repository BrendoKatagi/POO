package ex3;

public class Funcionario {
    private String sobreNome;
    private String nome;
    private double salarioHora;
    private int anosNaEmpresa;

    public void setSobrenome(String snome){
        sobreNome = snome;
    }

    public String getSobrenome(){
        return sobreNome;
    }

    public void setNome(String n){
        nome = n;
    }

    public String getNome(){
        return nome;
    }

    public void setSalHor(double valor){
        salarioHora = valor;
    }

    public double getSalHour(){
        return salarioHora;
    }

    public void setAnos(int anos){
        anosNaEmpresa = anos;
    }

    public int getAnos(){
        return anosNaEmpresa;
    }

    public static void statusEmpregado(Funcionario vetor[], int anos) {
        int anoEmpregado;

        for(int i = 0 ; i < vetor.length; i++){
            anoEmpregado = vetor[i].getAnos();
            
            if(anoEmpregado >= anos){
                System.out.println("Nome: " + vetor[i].getNome());
                System.out.println("Sobrenome: " + vetor[i].getSobrenome());
                System.out.println("Salário: " + vetor[i].getSalHour());
                System.out.print("\n");
            }
        }    
    }

    public static void main(String[] args) {
        Funcionario lista[] = new Funcionario[3];
        lista[0] = new Funcionario();
        lista[1] = new Funcionario();
        lista[2] = new Funcionario();

        lista[0].setNome("Paulo");
        lista[0].setSobrenome("Silva");
        lista[0].setSalHor(30.5);
        lista[0].setAnos(4);

        lista[1].setNome("Renata");
        lista[1].setSobrenome("de Souza");
        lista[1].setSalHor(45.2);
        lista[1].setAnos(6); 
        
        lista[2].setNome("Fabio");
        lista[2].setSobrenome("Teixeira");
        lista[2].setSalHor(25.7);
        lista[2].setAnos(2);

        statusEmpregado(lista, 4);

    }
}