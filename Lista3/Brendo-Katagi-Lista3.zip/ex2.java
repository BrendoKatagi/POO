public class ex2 {
    public static void media(Double vetor[]){
        double soma = 0;
        double media = 0;

        if(vetor.length != 0){
            
            for(int i =  0; i < vetor.length; i++){
                soma += vetor[i];
            }

            media = soma/vetor.length;
        }

        System.out.println("Média : " + media);
    }
    public static void main(String[] args) {
        Double[] vetor =  {42.5, 37.2, 12.8, 25.6};

        media(vetor);
    }
}
