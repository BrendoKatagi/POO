import java.util.Scanner;

public class ex1 {

    public static void selectionSort(int[] V){ //algoritmo para ordenação do vetor utilizando selection sort
        int menor, aux, comp, i;

        for(comp = 0; comp < V.length - 1; comp++){
            menor = comp;

            for(i = menor + 1; i < V.length; i++){
                if(V[i] < V[menor]){
                    menor = i;
                }
            }

            if(menor != comp){
                aux = V[comp];
                V[comp] = V[menor];
                V[menor] = aux;
            }
        }
        
    }
    public static void main(String[] args) {
        int[] vetor = new int[100];
        int num = -1, i = 0, j;

        Scanner teclado = new Scanner(System.in);

        System.out.println("Insira os números (insira 0 para parar)");

        while(num != 0){
            num = teclado.nextInt();

            if(num != 0 ){
                vetor[i] = num;
                i++;
            }    
        }

        teclado.close();

        selectionSort(vetor);

        System.out.println("Vetor ordenado: ");

        for(j= vetor.length - i; j< vetor.length; j++){
            System.out.printf("%d ",vetor[j]);
        }
    }
    
}