public class ex4 {
    
    public static int maiorInteiro(int vetor[], int inicio, int fim){
        int i;
        int maior = vetor[inicio];

        for(i = inicio; i < fim; i++){

            if(vetor[i] > maior){

                maior = vetor[i];
            
            }
        }

        return maior;
    }

    public static void buscaInteiro(int vetor[]){
        int meio, maior1, maior2, maior = 0;
        
        if(vetor.length > 0){

            meio = vetor.length/2;

            maior1 = maiorInteiro(vetor, 0, meio);
            maior2 = maiorInteiro(vetor, meio + 1, vetor.length);

            if(maior1 >= maior2){
                maior = maior1;
            }else{
                maior = maior2;
            }

            System.out.println("Maior inteiro: " + maior);
        }
    }

    public static void main(String[] args) {
        
        int[] vetor = {1, 2 , -5, 45, 4 , 6, 22, 17};

        buscaInteiro(vetor);
    }
}
