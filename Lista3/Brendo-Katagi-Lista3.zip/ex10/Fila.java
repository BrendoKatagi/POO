package ex10;

import java.util.LinkedList;

public class Fila {
    private LinkedList<Object> fila;

    public void inicializa(){
        fila = new LinkedList<Object>();       
    }

    public void enfileira(Object x){
        fila.addLast(x);        
    }

    public void desenfileira(){
        if(fila != null){
            System.out.println("Desenfileirando ...");
            System.out.println(fila.getFirst() + " Retirado\n");
            fila.removeFirst();
        }
    }

    public boolean vazio(){
        if(fila.isEmpty()){
            System.out.println("Fila está vazia!\n");           
            return true;
        }

        return false;
    }

    public static void main(String[] args) {
        
        Fila f1 = new Fila();
        f1.inicializa();
        f1.vazio();
        f1.enfileira("Primeiro da fila");
        f1.enfileira(2);
        f1.enfileira(3.3);       

        f1.desenfileira();
        f1.desenfileira();
        f1.desenfileira();
    }
}
