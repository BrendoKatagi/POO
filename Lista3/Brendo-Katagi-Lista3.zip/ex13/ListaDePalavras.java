package ex13;
import java.util.*;

public class ListaDePalavras {
    private Set lista;

    public ListaDePalavras() {
        lista = new TreeSet();
    }

    public void adiciona(String palavras) {
        StringTokenizer st = new StringTokenizer(palavras);
        while(st.hasMoreTokens())
            lista.add(st.nextToken());
    }

    public void setPalavra(String word){
        lista.add(word);
    }

    public boolean existe(String palavra) {
        return lista.contains(palavra);
    }

    public Set getLista(){
        return lista;
    }

    public static void main(String[] args) {
 
    }
}
