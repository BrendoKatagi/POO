import java.util.ArrayList;
import java.util.Random;

public class ex11 {
    
    public static class criaVetor{
        ArrayList<Double> vetor = new ArrayList<Double>(); 

        public criaVetor(int n) {

            Random r = new Random(); 

            for(int i = 0 ; i < n; i++){
                double num = r.nextDouble();
                 
                vetor.add(num);
            }

        }

        public void imprimeArray(){
            
            System.out.print(vetor);

        }
    }   

    public static void main(String[] args) {
        
        criaVetor v1 = new criaVetor(10);

        v1.imprimeArray();
    }
}
