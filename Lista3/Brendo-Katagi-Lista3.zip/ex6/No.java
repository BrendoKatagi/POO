package ex6;

public class No {
    private int dado; // Um item da lista
    private No prox; // Ponteiro para o próxim o

    public void setDado(int valor){
        dado = valor;
    }

    public int getDado(){
        return dado;
    }

    public void setProx(No p){
        prox = p;
    }

    public No getProx(){
        return prox;
    }

    public static class lista{
        private No posAtual;
        
        public void inserirNo(int valor){
    
            No novoNo = new No();
            novoNo.setDado(valor);
            novoNo.setProx(posAtual);
            posAtual = novoNo;
        }

        public No getPosAtual(){
            return posAtual;
        }
    
        public void inicializaLista(){
            posAtual = null;
    
        }
    
        public void imprimirLista(){
            No pos;
            int valor;
            
            pos = this.getPosAtual();
            
            while(pos.getProx() != null){
                valor = pos.getDado();
                System.out.printf(valor + " -> ");
                pos = pos.getProx();
            }
            valor = pos.getDado();
            System.out.println(valor);
        }    

        public No buscaElemento(int valor){
            No pos;
            No posAnterior;

            pos = posAtual;
            posAnterior = null;

            while(pos != null){
                if(pos.getDado() == valor){
                    System.out.println("Nó encontrado!");
                    return posAnterior;
                }
                posAnterior = pos;
                pos = pos.getProx();
            }

            System.out.println("Nó não foi encontrado!");

            return null;
        }

        public void removerNo(int valor){
            No aux;
            No atual;

            atual = buscaElemento(valor);

            if(atual != null){
                aux = atual.getProx();

                if(aux != null){
                    atual.setProx(aux.getProx());
                    aux.setDado(0);
                    aux.setProx(null);

                }

            }else{
                aux = posAtual;
                posAtual = posAtual.getProx();
                aux.setDado(0);
                aux.setProx(null);                
            }    
        }

        public void listaInvertida(lista l1){
            No aux;

            aux = l1.posAtual;

            while(aux != null){
                this.inserirNo(aux.getDado());
                aux = aux.getProx();
            }
        }

        public int somaValores(){
            int soma = 0;
            No aux;

            aux = posAtual;

            while(aux != null){
                soma += aux.getDado();
                aux = aux.getProx();
            }
            return soma;
        }
    }

    public static void main(String[] args) {
        lista l1  = new lista();
        lista l2  = new lista();

        l1.inicializaLista();
        l2.inicializaLista();

        l1.inserirNo(10);
        l1.inserirNo(50);
        l1.inserirNo(20);
        l1.inserirNo(30);
        System.out.println("Lista : ");
        l1.imprimirLista();    
        System.out.println();
        //l1.buscaElemento(20);
        //l1.buscaElemento(40);

        l1.removerNo(30);
        System.out.println("Lista após remoção: ");
        l1.imprimirLista(); 

        l2.listaInvertida(l1);
        System.out.println();
        System.out.println("Lista invertida: ");
        l2.imprimirLista();

        System.out.println();
        System.out.println("Soma dos valores: " + l1.somaValores());
    }
    
}
