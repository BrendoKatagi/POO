
public class ex7 {

    static void imprimeAlgo(int nivel) {
   
        if (nivel == 0) {
            System.out.print("*");
        } else {
            System.out.print("[");
            imprimeAlgo(nivel - 1);
            System.out.print(",");
            imprimeAlgo(nivel - 1);
            System.out.println("]");
        }
    }

    public static void main(String[] args) {
        System.out.println("0:");
        imprimeAlgo(0);
        System.out.println();
        System.out.println("1:");
        imprimeAlgo(1);
        System.out.println();
        System.out.println("2:");
        imprimeAlgo(2);
        System.out.println();        
        System.out.println("3:");
        imprimeAlgo(3);

    }
}
